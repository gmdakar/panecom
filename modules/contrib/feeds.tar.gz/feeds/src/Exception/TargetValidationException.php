<?php

namespace Drupal\feeds\Exception;

/**
 * Thrown if the target values are invalid and cannot be recovered.
 */
class TargetValidationException extends ValidationException {}
