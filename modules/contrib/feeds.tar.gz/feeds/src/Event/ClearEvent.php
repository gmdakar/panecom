<?php

namespace Drupal\feeds\Event;

/**
 * Fired to being clearing.
 */
class ClearEvent extends EventBase {}
