<?php

namespace Drupal\feeds;

use Drupal\views\EntityViewsData;

/**
 * Provides the views data for the feeds_feed entity type.
 */
class FeedViewsData extends EntityViewsData {

}
