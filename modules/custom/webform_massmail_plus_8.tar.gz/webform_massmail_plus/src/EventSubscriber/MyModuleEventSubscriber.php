<?php

namespace Drupal\webform_massmail_plus\EventSubscriber;
use \Symfony\Component\EventDispatcher\EventSubscriberInterface;
use \Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\HttpKernel\Event\FilterResponseEvent;

class MyModuleEventSubscriber implements EventSubscriberInterface {

  /**
   * Set header 'Content-Security-Policy' to response to allow embedding in iFrame.
   */
  public function setHeaderContentSecurityPolicy(FilterResponseEvent $event) {
    $response = $event->getResponse();
    $response->headers->remove('X-Frame-Options');
    $response->headers->set('Content-Security-Policy', "frame-ancestors 'self' https://www.facebook.com/ *.facebook.com", FALSE);
	\Drupal::logger('mytools')->notice("mytools_form_views_exposed_form_alter event:". '<pre><code>' . print_r("setHeaderContentSecurityPolicy", TRUE) . '</code></pre>' );
  }

  /**
   * {@inheritdoc}
   */
  static function getSubscribedEvents() {
    // Response: set header content security policy
    $events[KernelEvents::RESPONSE][] = ['setHeaderContentSecurityPolicy', -10];
    
    return $events;
  }

}