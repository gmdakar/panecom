<?php

namespace Drupal\webform_massmail_plus\Form;

use mikehaertl\pdftk\Pdf;
use Drupal\Core\Database\Connection;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\webform_mass_email\Form\WebformResultsMassEmailForm;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Queue\QueueFactory;
use Drupal\webform\WebformInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Send mass email to address stored in webform field.
 */
class WebformResultsMassEmailPlusForm extends WebformResultsMassEmailForm {

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    \Drupal::logger('webform_massmail_plus')->notice("webform_massmail_plus submitForm2!");
	$webform = $form_state->getValue('webform');
    $element = $form_state->getValue('element');
    $element_types = $form_state->getValue('element_types');
    $subject = $form_state->getValue('subject');
    $body = $form_state->getValue('body');
    if (is_array($body) && isset($body['value'])) {
      $body = $body['value'];
    }

    // Get all emails keyed by submissions ID.
    $query = $this->database->select('webform_submission_data', 's');
	$query->addField('s', 'sid');
	/*$query->addField('s', 'value', 'mail');
	$query->fields('s3', ['sid', 'name', 'property']);
	$query->addField('s3', 'value', 'first_name');*/
	//filter by type of results (succeded/failed after assessments)
	$query->join('webform_submission_data', 's2', 's.sid = s2.sid');
	//$query->join('webform_submission_data', 's3', 's.sid = s3.sid');
	//$query->addField('s4', 'value', 'last_name');
    $query->condition('s.webform_id', $webform['id']);
    //$query->condition('s.name', $element);	*/
	$query->condition('s2.name', 'selection');
	$query->condition('s2.value', 'oui');
	/*$query->condition('s3.name', 'nom');
	$query->condition('s3.value', 'first');*/
	
	//$query->join('webform_submission_data', 's4', 's4.name = :name AND s4.property = :prop AND s.sid = s4.sid', array( ':name' => 'nom', ':prop' => 'last'));
    $query->groupBy('s.sid');
	$result = $query->execute();
	//dump($query->__toString());
	//\Drupal::logger('webform_massmail_plus submissions')->notice("webform_massmail_plus submissions3". '<pre><code>' . print_r($query->__toString(), TRUE) . '</code></pre>' );
	$submissions = $result->fetchAll();
	\Drupal::logger('webform_massmail_plus submissions')->notice("webform_massmail_plus submissions". '<pre><code>' . print_r($submissions, TRUE) . '</code></pre>' );
	
    // Prepare the values that we're going to put into the queue.
    $queue_values = [
      'webform_id' => $webform['id'],
      'webform_title' => $webform['title'],
      'subject' => $subject,
      'body' => $body,
    ];

    $count = 0;
    // Store all emails here for to prevent any duplicates.
    $emails = [];

    // Loop through the submissions, pick up submission ID + email and
    // enqueue the request for the cron to fetch.
    foreach ($submissions as $id => $objsubmission) {
		
		$queue_values['webform_sid'] = $objsubmission->sid ;
		\Drupal::logger('webform_massmail_plus objsubmission')->notice("webform_massmail_plus objsubmission->sid". $objsubmission->sid );
								
		// Load submission using sid.
		/** @var \Drupal\webform\WebformSubmissionInterface $webform_submission */
		$webform_submission = \Drupal\webform\Entity\WebformSubmission::load($objsubmission->sid);
		$submission_data = $webform_submission->getData();
		\Drupal::logger('webform_massmail_plus objsubmission')->notice("webform_massmail_plus submission_data ". '<pre><code>' . print_r($submission_data, TRUE) . '</code></pre>' );
		
		$html = str_replace(array("@@_first_name_@@", "@@_last_name_@@", "@@_sid_@@"), 
								array($this->stripAccents($submission_data['nom']['first']),$this->stripAccents($submission_data['nom']['last']), $objsubmission->sid),
								$body
								);
		$queue_values['body'] = $html;
		
		//generate pdf file for each submission
		$modulePath = \Drupal::service('module_handler')->getModule('webform_massmail_plus')->getPath();
		$modelePDf_file = $modulePath . "/lettre_invitation_modele_last.pdf"; //modele template pdf to fill

		$PDf_filled_file = $modulePath.'/filled_'.$this->stripAccents($submission_data['nom']['first']).'_'.$this->stripAccents($submission_data['nom']['last']).'_'.$objsubmission->sid.'.pdf';
		\Drupal::logger('webform_massmail_plus')->notice("webform_massmail_plus_pdf_filled1:". '<pre><code>' . $PDf_filled_file. '</code></pre>' );
		
		//$error = false;
		/*try {
		  
		}
		catch (Exception $e) {
		  // Generic exception handling if something else gets thrown.
		  \Drupal::logger('webform_massmail_plus')->error($e->getMessage());
		  \Drupal::logger('webform_massmail_plus objsubmission')->notice("PDf_filled_file error". $PDf_filled_file );
		   $error = true;
		   \Drupal::messenger()->addError("webform_massmail_plus PDf_filled_file error: ". $PDf_filled_file);
		   return false;

		}*/
		
		//$tempstore = \Drupal::service('tempstore.private')->get('mymodule');
		
		// Create FDF from PDF
		$pdf = new Pdf($modelePDf_file);
		$result = $pdf->fillForm(['untitled1' => $this->stripAccents($submission_data['nom']['first']),'untitled2' => $this->stripAccents($submission_data['nom']['last']),'untitled4' => $objsubmission->sid])
			->needAppearances()
			->saveAs($PDf_filled_file);
			
		// Always check for errors
		if ($result === false) {
			$error = $pdf->getError();
			\Drupal::logger('webform_massmail_plus')->error("PDf_filled_file error". $PDf_filled_file);
			 \Drupal::logger('webform_massmail_plus objsubmission')->notice("PDf_filled_file error". $PDf_filled_file );
			 \Drupal::logger('webform_massmail_plus objsubmission')->notice("PDf_filled_file error var ". '<pre><code>' . print_r($error, TRUE) . '</code></pre>' );
			 return false;
		}
		
		
		\Drupal::logger('webform_massmail_plus objsubmission')->notice("PDf_filled_file ok". $PDf_filled_file );
		$queue_values['webform_file1'] = $PDf_filled_file;
		//$tempstore->set('webform_file1_'.$objsubmission->sid, $PDf_filled_file);
		
		try {
			//create pdf with mpdf
			//$html = "this is my <b>good</b>downloadable pdf";
			
			$mpdf = new \Mpdf\Mpdf(['tempDir' => 'sites/default/files/tmp']); $mpdf->WriteHTML($html);
			//ob_clean();
			$file2 = "sites/default/files/tmp/file_".$this->stripAccents($submission_data['nom']['first']).'_'.$this->stripAccents($submission_data['nom']['last']).'_'.$objsubmission->sid.".pdf";
			$mpdf->Output($file2, 'F');
			$queue_values['webform_file2'] = $file2;
			//$tempstore->set('webform_file2_'.$objsubmission->sid, $PDf_filled_file);
		}
		catch (Exception $e) {
		  \Drupal::logger('webform_massmail_plus objsubmission')->notice("Mpdf error var ". '<pre><code>' . print_r($e, TRUE) . '</code></pre>' );
		   return false;

		}
		
		\Drupal::logger('webform_massmail_plus objsubmission')->notice("lets create queue items..");
		//lets create queue items..
		$values = [];
		
		$email =  $submission_data['mail'];

		// Split multiple emails inside single submission.
		if ($element_types[$element] === 'webform_email_multiple') {
			foreach (preg_split('/\s*,\s*/', $email) as $value) {
			  $values[] = trim($value);
			}
		}
		else {
			// Use single value for all other element types.
			$values[] = trim($email);
		}

		foreach ($values as $value) {
			// There's email for this submission and it's not already queued.
			if (!empty($value) && !in_array($value, $emails)) {
			  // Set queue values.
			  $queue_values['id'] = $id;
			  $queue_values['email'] = $value;

			  // Queue the values into the 'queue' table.
			  $queue = $this->queueFactory->get('webform_mass_email');
			  $queue->createItem($queue_values);
			  \Drupal::logger('webform_massmail_plus objsubmission')->notice("lets create queue items queue_values: ". '<pre><code>' . print_r($queue_values, TRUE) . '</code></pre>' );
			  $count++;
			  // Store the email.
			  $emails[] = $value;
			}
		}
	
    }

    // Set message with the count.
    $this->messenger()->addMessage($this->t('%count items queued for sending.', [
      '%count' => $count,
    ]));
  }
  
  /*Tools remove accents*/
  function stripAccents($str) {
	$str = preg_replace('/\s+/', '', $str);
	$str = strtr(utf8_decode($str), utf8_decode('àáâãäçèéêëìíîïñòóôõöùúûüýÿÀÁÂÃÄÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝ'), 'aaaaaceeeeiiiinooooouuuuyyAAAAACEEEEIIIINOOOOOUUUUY');
	return mb_strtolower($str);
  }

}
