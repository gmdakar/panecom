<?php

namespace Drupal\webform_massmail_plus\Routing;

use Drupal\Core\Routing\RouteSubscriberBase;
use Symfony\Component\Routing\RouteCollection;

/**
 * Listens to the dynamic route events.
 */
class RouteSubscriber extends RouteSubscriberBase {

  /**
   * {@inheritdoc}
   */
  protected function alterRoutes(RouteCollection $collection) {
    // Change path '/user/login' to '/login'.
    if ($route = $collection->get('entity.webform.results_mass_email')) {
      $route->setDefault('_form', '\Drupal\webform_massmail_plus\Form\WebformResultsMassEmailPlusForm');
    }
  }

}