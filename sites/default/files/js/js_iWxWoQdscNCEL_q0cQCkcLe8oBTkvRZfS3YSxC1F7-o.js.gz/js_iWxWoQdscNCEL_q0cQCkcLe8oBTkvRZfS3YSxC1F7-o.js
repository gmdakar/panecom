/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.behaviors.panecom_bstrp = {
    attach: function (context, settings) {

    }
  };

})(jQuery, Drupal);
;
