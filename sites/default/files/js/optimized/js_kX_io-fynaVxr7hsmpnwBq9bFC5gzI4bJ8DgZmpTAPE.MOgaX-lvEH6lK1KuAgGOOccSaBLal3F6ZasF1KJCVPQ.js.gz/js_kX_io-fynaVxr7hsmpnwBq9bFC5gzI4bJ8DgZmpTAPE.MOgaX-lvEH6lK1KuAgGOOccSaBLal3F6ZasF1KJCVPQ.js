/* Source and licensing information for the line(s) below can be found at https://devpanecom.digissol.pro/core/assets/vendor/jquery.ui/ui/ie-min.js. */
!function(e){"use strict";"function"==typeof define&&define.amd?define(["jquery","./version"],e):e(jQuery)}((function(e){"use strict";return e.ui.ie=!!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase())}));
//# sourceMappingURL=ie-min.js.map
/* Source and licensing information for the above line(s) can be found at https://devpanecom.digissol.pro/core/assets/vendor/jquery.ui/ui/ie-min.js. */