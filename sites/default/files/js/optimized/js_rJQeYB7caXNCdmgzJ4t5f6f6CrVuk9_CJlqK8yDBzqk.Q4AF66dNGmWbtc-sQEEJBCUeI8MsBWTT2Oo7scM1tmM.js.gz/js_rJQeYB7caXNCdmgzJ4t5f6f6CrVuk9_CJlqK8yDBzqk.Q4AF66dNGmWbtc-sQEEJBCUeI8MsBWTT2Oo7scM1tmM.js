/* Source and licensing information for the line(s) below can be found at https://devpanecom.digissol.pro/core/assets/vendor/jquery.ui/ui/version-min.js. */
!function(e){"use strict";"function"==typeof define&&define.amd?define(["jquery"],e):e(jQuery)}((function(e){"use strict";return e.ui=e.ui||{},e.ui.version="1.13.1"}));
//# sourceMappingURL=version-min.js.map
/* Source and licensing information for the above line(s) can be found at https://devpanecom.digissol.pro/core/assets/vendor/jquery.ui/ui/version-min.js. */