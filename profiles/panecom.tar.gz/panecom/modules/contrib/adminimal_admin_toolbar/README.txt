This module is inspired by "Adminimal Administration Menu". It provides a
minimalist style to the "Admin Toolbar" module.

Although "Adminimal" provides menu styling, there some conflicts with Admin
toolbar and styling will only be present when the admin theme is present.

For this reason it makes the most sense to put this styling in a module rather
than the theme.


Installation
------------

By downloading and enabling this module styling will be applied.


Dependencies
------------

- admin_toolbar
