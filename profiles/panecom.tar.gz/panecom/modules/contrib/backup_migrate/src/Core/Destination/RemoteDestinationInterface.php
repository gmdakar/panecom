<?php

namespace Drupal\backup_migrate\Core\Destination;

/**
 * Interface RemoteDestinationInterface.
 *
 * @package Drupal\backup_migrate\Core\Destination
 */
interface RemoteDestinationInterface extends DestinationInterface {

}
